# Yauheni Shuliakouski
**Phone number:** +375 29 713-79-70   
**e-mail:** zheka1609@yandex.ru   
**Github profile:** [Aidix](https://github.com/Aidix)   

## Objective:
Start a junior JavaScript developer career in the company and in 5 years grow to the team leader   

## Skills:
* JavaScript   
* Work experience with HTML/CSS   
* C++, C#   

## Education:
* A javascript/front-end course at the Rolling Scopes School in 2019 year  
* BSUIR, Faculty of information technologies and control, Information Technologies in Automated Systems, 2014 - 2018 years 

## English level:
A2(Pre-intermediate)   




